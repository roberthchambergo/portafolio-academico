package Arreglo;

import java.util.Arrays;
import java.util.Scanner;

/**
 * ABSTRACCION: clase abstracta que representa "un arreglo de enteros con tope".
 * No se puede instanciar directamente; obliga a las clases hijas a implementar
 * mostrarInformacion().
 *
 * ENCAPSULAMIENTO: los atributos son private y solo se accede a ellos
 * mediante getters y setters (con validacion).
 */
public abstract class ArregloBase {

    // Un solo Scanner compartido por todo el programa
    public static final Scanner TECLADO = new Scanner(System.in);

    // Atributos encapsulados
    private int[] numerito;
    private int tope;

    // Constructor por defecto
    public ArregloBase() {
        this.numerito = null;
        this.tope = 0;
    }

    // Constructor con parametro
    public ArregloBase(int valor) {
        if (valor < 1) {
            throw new IllegalArgumentException("El tamano debe ser mayor que 0.");
        }
        this.numerito = new int[valor];
        this.tope = 0;
    }

    // Constructor copia (lo usan las clases hijas)
    protected ArregloBase(ArregloBase otro) {
        if (otro.numerito == null) {
            this.numerito = null;
            this.tope = 0;
        } else {
            this.numerito = Arrays.copyOf(otro.numerito, otro.numerito.length);
            this.tope = otro.tope;
        }
    }

    // Getter y Setter de numerito
    public int[] getNumerito() {
        return numerito;
    }

    public void setNumerito(int[] numerito) {
        this.numerito = numerito;
    }

    // Getter y Setter de tope (el setter valida el rango)
    public int getTope() {
        return tope;
    }

    public void setTope(int tope) {
        int capacidad = (numerito == null) ? 0 : numerito.length;
        if (tope < 0 || tope > capacidad) {
            throw new IllegalArgumentException("Tope fuera de rango: " + tope);
        }
        this.tope = tope;
    }

    // Metodo para crear el arreglo
    public void creaArreglo(int valor) {
        setNumerito(new int[valor]);
        setTope(0);
    }

    // ---------- Metodos de consulta (no imprimen nada) ----------
    public boolean estaCreado() {
        return numerito != null;
    }

    public boolean tieneDatos() {
        return numerito != null && tope > 0;
    }

    public boolean estaLleno() {
        return numerito != null && tope == numerito.length;
    }

    /** Devuelve la posicion (0..tope-1) de la primera aparicion de x, o -1. */
    protected int buscar(int x) {
        for (int i = 0; i < tope; i++) {
            if (numerito[i] == x) {
                return i;
            }
        }
        return -1;
    }

    // ---------- Verificaciones que informan al usuario ----------
    public boolean verificaCreado() {
        if (!estaCreado()) {
            System.out.println("Primero debe crear el arreglo.");
            return false;
        }
        return true;
    }

    public boolean verificaConDatos() {
        if (!verificaCreado()) {
            return false;
        }
        if (tope == 0) {
            System.out.println("El arreglo no tiene elementos.");
            return false;
        }
        return true;
    }

    public boolean verificaConEspacio() {
        if (!verificaCreado()) {
            return false;
        }
        if (estaLleno()) {
            System.out.println("El arreglo esta lleno, no se puede insertar.");
            return false;
        }
        return true;
    }

    // ---------- Entrada de datos ----------
    /** Lee un entero validando que el usuario escriba un numero. */
    public static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            if (TECLADO.hasNextInt()) {
                return TECLADO.nextInt();
            }
            System.out.println("Valor no valido. Ingrese un numero entero.");
            TECLADO.next();
        }
    }

    // Metodo para ingresar datos (un numero por llamada)
    public void lectura() {
        if (!verificaCreado()) {
            return;
        }

        if (getTope() < getNumerito().length) {
            getNumerito()[getTope()] = getNumero();
            setTope(getTope() + 1);
        } else {
            System.out.println("El arreglo esta lleno.");
        }
    }

    // Metodo para leer un numero
    public int getNumero() {
        return leerEntero("Ingrese Numero : ");
    }

    // Metodo para mostrar datos (las hijas pueden sobrescribirlo)
    public void escritura() {
        System.out.println("\tListado");
        System.out.println("\t--------");

        if (!tieneDatos()) {
            System.out.println("No hay elementos");
        } else {
            for (int i = 0; i < getTope(); i++) {
                System.out.print(getNumerito()[i] + "\t");
            }
        }
        System.out.println();
    }

    /** Metodo abstracto: cada clase hija lo implementa a su manera. */
    public abstract void mostrarInformacion();
}
