package Arreglo;

/**
 * HERENCIA: Arreglos extiende ArregloBase y reutiliza sus atributos y metodos.
 * Aqui van las operaciones que MODIFICAN el arreglo (actividades 1, 2, 3, 7 y 8).
 */
public class Arreglos extends ArregloBase {

    public Arreglos() {
        super();
    }

    public Arreglos(int valor) {
        super(valor);
    }

    public Arreglos(ArregloBase otro) {
        super(otro);
    }

    // 1. Eliminar un elemento "x" 
    public boolean eliminar(int x) {
        if (!verificaConDatos()) {
            return false;
        }

        int pos = buscar(x);
        if (pos == -1) {
            System.out.println("El elemento " + x + " no se encuentra en el arreglo.");
            return false;
        }

        int[] a = getNumerito();
        for (int i = pos; i < getTope() - 1; i++) {
            a[i] = a[i + 1];          // se corren los elementos a la izquierda
        }
        a[getTope() - 1] = 0;
        setTope(getTope() - 1);
        System.out.println("Elemento " + x + " eliminado correctamente.");
        return true;
    }

    // 2. Modificar un elemento "x" por un valor nuevo
    public boolean modificar(int x, int nuevo) {
        if (!verificaConDatos()) {
            return false;
        }

        int pos = buscar(x);
        if (pos == -1) {
            System.out.println("El elemento " + x + " no se encuentra en el arreglo.");
            return false;
        }

        getNumerito()[pos] = nuevo;
        System.out.println("Elemento " + x + " modificado por " + nuevo + ".");
        return true;
    }

    // 3. Insertar un elemento "x" en la posicion "y"
    public boolean insertar(int x, int y) {
        if (!verificaConEspacio()) {
            return false;
        }
        if (y < 1 || y > getTope() + 1) {
            System.out.println("Posicion invalida. Debe estar entre 1 y " + (getTope() + 1) + ".");
            return false;
        }

        int[] a = getNumerito();
        for (int i = getTope(); i > y - 1; i--) {
            a[i] = a[i - 1];          // se corren los elementos a la derecha
        }
        a[y - 1] = x;
        setTope(getTope() + 1);
        System.out.println("Elemento " + x + " insertado en la posicion " + y + ".");
        return true;
    }

    // POLIMORFISMO ESTATICO (sobrecarga): mismo nombre, distintos parametros.
    // Inserta x al final del arreglo.
    public boolean insertar(int x) {
        return insertar(x, getTope() + 1);
    }

    // 7. Mover el primer elemento a la ultima posicion
    public void moverPrimeroAlUltimo() {
        if (!verificaConDatos()) {
            return;
        }

        int[] a = getNumerito();
        int primero = a[0];
        for (int i = 0; i < getTope() - 1; i++) {
            a[i] = a[i + 1];
        }
        a[getTope() - 1] = primero;
        System.out.println("El primer elemento (" + primero + ") paso a la ultima posicion.");
    }

    // 8. Mover el primer elemento par al final del arreglo
    public void moverPrimerParAlFinal() {
        if (!verificaConDatos()) {
            return;
        }

        int[] a = getNumerito();
        int pos = -1;
        for (int i = 0; i < getTope(); i++) {
            if (a[i] % 2 == 0) {
                pos = i;
                break;
            }
        }

        if (pos == -1) {
            System.out.println("No hay elementos pares en el arreglo.");
            return;
        }

        int par = a[pos];
        for (int i = pos; i < getTope() - 1; i++) {
            a[i] = a[i + 1];
        }
        a[getTope() - 1] = par;
        System.out.println("El primer par (" + par + ") paso al final del arreglo.");
    }

    // POLIMORFISMO DINAMICO (sobrescritura): implementacion del metodo abstracto
    @Override
    public void mostrarInformacion() {
        System.out.println("[Arreglos] Operaciones de edicion: eliminar, modificar, insertar y mover elementos.");
    }
}
