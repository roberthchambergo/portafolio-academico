package Arreglo;

public class AplicaArreglos {

    // Referencia a la clase hija mas completa (herencia)
    static ArregloEstadistico objArreglo = new ArregloEstadistico();

    public static void main(String[] args) {
        menu();
    }

    static void menu() {
        int opcion, tam, x, y, nuevo;

        do {
            System.out.println("    Menu de Opciones");
            System.out.println("=====================");
            System.out.println("1.- Crear Arreglo");
            System.out.println("=====================");
            System.out.println("2.- Ingresar Datos");
            System.out.println("3.- Mostrar Datos");
            System.out.println("=====================");
            System.out.println("4.- Eliminar elemento x");
            System.out.println("5.- Modificar elemento x");
            System.out.println("6.- Insertar elemento x en posicion y");
            System.out.println("=====================");
            System.out.println("7.- Sumar elementos");
            System.out.println("8.- Menor, Mayor y Promedio");
            System.out.println("9.- Suma de Impares");
            System.out.println("=====================");
            System.out.println("10.- Mover primer elemento al ultimo");
            System.out.println("11.- Mover primer par al final");
            System.out.println("=====================");
            System.out.println("12.- Demostracion de Polimorfismo");
            System.out.println("=====================");
            System.out.println("0.- Salir");
            System.out.println("=====================");

            opcion = ArregloBase.leerEntero("Ingrese una Alternativa : ");
            System.out.println("");

            switch (opcion) {
                case 1:
                    do {
                        tam = ArregloBase.leerEntero("Ingrese Tamano del Arreglo : ");
                        if (tam < 1) {
                            System.out.println("El tamano debe ser mayor que 0.");
                        }
                    } while (tam < 1);
                    // Uso del constructor con parametro
                    objArreglo = new ArregloEstadistico(tam);
                    break;

                case 2:
                    objArreglo.lectura();
                    break;

                case 3:
                    objArreglo.escritura();
                    break;

                case 4:
                    if (objArreglo.verificaConDatos()) {
                        x = ArregloBase.leerEntero("Ingrese el elemento a eliminar : ");
                        objArreglo.eliminar(x);
                    }
                    break;

                case 5:
                    if (objArreglo.verificaConDatos()) {
                        x = ArregloBase.leerEntero("Ingrese el elemento a modificar : ");
                        nuevo = ArregloBase.leerEntero("Ingrese el nuevo valor : ");
                        objArreglo.modificar(x, nuevo);
                    }
                    break;

                case 6:
                    if (objArreglo.verificaConEspacio()) {
                        x = ArregloBase.leerEntero("Ingrese el elemento a insertar : ");
                        y = ArregloBase.leerEntero("Ingrese la posicion (1 a " + (objArreglo.getTope() + 1) + ") : ");
                        objArreglo.insertar(x, y);
                    }
                    break;

                case 7:
                    objArreglo.mostrarSuma();
                    break;

                case 8:
                    objArreglo.mostrarEstadisticas();
                    break;

                case 9:
                    objArreglo.mostrarSumaImpares();
                    break;

                case 10:
                    objArreglo.moverPrimeroAlUltimo();
                    break;

                case 11:
                    objArreglo.moverPrimerParAlFinal();
                    break;

                case 12:
                    demostracionPolimorfismo();
                    break;

                case 0:
                    System.out.println("Saliendo del sistema ....");
                    break;

                default:
                    System.out.println("Opcion no valida.");
            }
            System.out.println("");

        } while (opcion != 0);
    }

    // POLIMORFISMO: una lista de tipo ArregloBase guarda objetos de distintas
    // clases hijas; al llamar al mismo metodo, cada objeto responde a su manera.
    static void demostracionPolimorfismo() {
        Arreglos copia = new Arreglos(objArreglo);
        ArregloBase[] lista = {objArreglo, copia};

        for (ArregloBase a : lista) {
            a.mostrarInformacion();
            a.escritura();
        }
    }
}
