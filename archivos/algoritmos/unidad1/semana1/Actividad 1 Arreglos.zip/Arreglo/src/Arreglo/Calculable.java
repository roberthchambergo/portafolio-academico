package Arreglo;

/**
 * ABSTRACCION (interfaz): define QUE calculos debe ofrecer un arreglo
 * estadistico, sin decir COMO se calculan. Cada clase que la implemente
 * decide los detalles.
 */
public interface Calculable {

    int sumar();

    int hallarMenor();

    int hallarMayor();

    double hallarPromedio();

    int sumarImpares();
}
